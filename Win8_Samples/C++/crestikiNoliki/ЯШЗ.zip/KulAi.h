#include <utility>

using namespace std;

const string KulAiName = "AlwaysPlaceIn(1;1)";

pair<int, int> KulAi(string field, int W){

    pair<int,int> temp;
    temp.first = 1;
    temp.second = 1;
    return temp;
}
