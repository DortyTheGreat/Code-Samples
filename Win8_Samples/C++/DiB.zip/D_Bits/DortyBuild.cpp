/*
---------------------
This File was Build Automatically by DortyBuild v 1.3.
For More Information ask:
Discord: �����#9030 
---Original---Code---

#include <iostream>
#include "DortyLibs/DortyBuild.h"
#include "DortyLibs/DortyMath.h"
#include "DortyLibs/DortyString.h"
#include "DortyLibs/DortyGeometry.h"
#include <iomanip>

using namespace std;

int main()
{
    AppBuild();
    Point a,b;
    //cin >> a >> b;
    Line li;
    cin >> li;
    cin >> a;
    li.make_perpendicular_to_point(a);

    cout << fixed << setprecision(8)<<li;




    return 0;
}

*/
#include <iostream>
#include <cmath>

using namespace std;

long long NOD(long long a,long long b){

   if(a<b){swap(a,b);}
   while(1){
        a=a%b;
        if(a==0){break;}else{if(a<b){swap(a,b);}}
   }
  return b;

}

bool IsPrime(long long a){
    if(a < 2){return 0;}
    if(sqrt(a) == int(sqrt(a))){return 0;}
    for(int i=2;i<sqrt(a);i++){
        if(a%i == 0){return 0;}
    }
    return 1;
}

#include <sstream>
template <typename T>
  std::string NumberToString ( T Number )
  {
     std::ostringstream ss;
     ss << Number;
     return ss.str();
  }



double PI = 3.14159265358979323846 ;

double Epsilon = 0.00001;
bool doubleEqual(double a, double b){
    return (abs(a-b) <= Epsilon);
}


double ToDegree(double rad){
    return rad*180/PI;
}
double ToRad(double degree){
    return degree* PI/180;
}


class Angle{
public:
    double radian;
    Angle(){
        radian=PI;
    }
    Angle(double _radian){
        radian = _radian;
    }

    bool isReverse(Angle angle_){
        return doubleEqual(radian+PI, angle_.radian) || doubleEqual(radian-PI, angle_.radian);
    }

};


///Dorty Utility
void YesNo(bool arg){
    if (arg){
        cout << "YES" << endl;
    }else{
        cout << "NO" << endl;
    }
}





class Point{
public:
    double X,Y;
    Point(double _X, double _Y){
        X = _X;
        Y=  _Y;
    }

    Point(){
        X = 0;
        Y=  0;
    }

    bool operator== (Point second){
        return (X==second.X) && (Y == second.Y);
    }

    Point operator+(Point second){
        return Point(X+second.X,Y+second.Y);
    }

    Point operator*(double mult){
        return Point(X*mult,Y*mult);
    }


    Point(double distance, double AngleRad, bool nullen){
        double sX = cos(AngleRad);
        double sY = sin(AngleRad);
        X = sX * distance;
        Y = sY * distance;
    }
    double getRotation(){
        if(Y == 0){
            if(X >= 0){
                return 0;
            }else{
                return PI;
            }
        }
        if(Y < 0 ){
            return PI * 3/2 - atan( X / Y );
        }else{
            return PI/2 - atan( X / Y );
        }
    }
    friend istream& operator>> (std::istream &in, Point &point)
    {
        // Поскольку operator>> является другом класса Point, то мы имеем прямой доступ к членам Point.
        // Обратите внимание, параметр point (объект класса Point) должен быть неконстантным, чтобы мы имели возможность изменить члены класса
        in >> point.X;
        in >> point.Y;

        return in;
    }

    friend ostream& operator<< (std::ostream &out, const Point &point)
    {
        // Поскольку operator<< является другом класса Point, то мы имеем прямой доступ к членам Point
        out << point.X << " " << point.Y;

        return out;
    }

};



class Line{
public:
    double A,B,C;

    friend istream& operator>> (std::istream &in, Line &line)
    {
        // Поскольку operator>> является другом класса Point, то мы имеем прямой доступ к членам Point.
        // Обратите внимание, параметр point (объект класса Point) должен быть неконстантным, чтобы мы имели возможность изменить члены класса
        in >> line.A;
        in >> line.B;
        in >> line.C;

        return in;
    }

    friend ostream& operator<< (std::ostream &out, const Line &line)
    {
        // Поскольку operator<< является другом класса Point, то мы имеем прямой доступ к членам Point
        out << line.A << " " << line.B << " " << line.C;

        return out;
    }

    Line(Point first, Point second){
        double dX = second.X - first.X;
        double dY = second.Y - first.Y;

        A = dY;
        B = -1 * dX;
        C = first.Y*dX - first.X * dY;

        if (!doubleEqual(dX,0)){
            ///Нормальная, меняется по иксу

        }else{
            /// ненормальная, вертикальная
        }

    }
    Line(){
    A = 1;
    B = 1;
    C = 0;
    }

    double getY_byX(double X){
        double template_null = 1337;
        if (!doubleEqual(B,0)){
            ///Нормальная, меняется по иксу
            return -1 * (A*X + C)/B;

        }else{

            return template_null;

        }
    }

    int which_side(Point point){

        if (!doubleEqual(B,0)){
            ///Нормальная, меняется по иксу
            double Y_ = getY_byX(point.X);
            return (Y_ > point.Y);

        }else{
            ///cout << "here" << endl;
            ///return template_null;
            double x_coord = -1 * C / A;
            ///cout << x_coord << " " << point.X << " "<< (point.X > x_coord) << endl;
            return (point.X > x_coord);

            /// ненормальная, вертикальная
        }


    }

    bool DoesContainPoint(Point point){

        if (!doubleEqual(B,0)){
            ///Нормальная, меняется по иксу
            double Y_ = getY_byX(point.X);
            return doubleEqual(Y_,point.Y);

        }else{
            ///cout << "here" << endl;
            ///return template_null;
            double x_coord = -1 * C / A;
            ///cout << x_coord << " " << point.X << " "<< (point.X > x_coord) << endl;
            return doubleEqual(point.X, x_coord);

            /// ненормальная, вертикальная
        }


    }

    double distance_to_point(Point point_){
        return abs(A*point_.X + B*point_.Y + C)/(sqrt(A*A+B*B));
    }
    /// 1 - ровно в одной точке, 0 - нет пересечений, 2 - всё пересекается
    pair<int, Point> intersection(Line another_line){

        if (doubleEqual(A*another_line.B,B*another_line.A)){
            /// the same or parallel


            bool is_same_flag;

            ///cout << C/A << " " << another_line.C/another_line.A << endl;

            if (doubleEqual(B,0)){
                is_same_flag = doubleEqual(C/A,another_line.C/another_line.A);
            }else{
                is_same_flag = doubleEqual(C/B,another_line.C/another_line.B);
            }

            ///cout << is_same_flag << endl;
            return make_pair(is_same_flag*2,Point());



        }else{
            /// не равны

            double x_coord = (C*another_line.B-another_line.C*B)/ (another_line.A * B - A* another_line.B);



            if (doubleEqual(B,0)){
                return make_pair(1,Point(x_coord, another_line.getY_byX(x_coord)));
            }else{
                return make_pair(1,Point(x_coord, getY_byX(x_coord)));
            }
        }



    }

    void make_perpendicular_to_point(Point point_){
        swap(A,B);
        B *= (-1);
        if (doubleEqual(A,0)){
            B *= -1;
            C = (-1) * (point_.Y * B);
            return;
        }
        double MyY = getY_byX(point_.X);

        if (doubleEqual(B,0)){
            C = (-1) * (point_.X * A);
            return;
        }


            C = C - (MyY - point_.Y);



    }

};



class Segment{
public:
    Point Point1, Point2;

    friend istream& operator>> (std::istream &in, Segment &segment)
    {
        // Поскольку operator>> является другом класса Point, то мы имеем прямой доступ к членам Point.
        // Обратите внимание, параметр point (объект класса Point) должен быть неконстантным, чтобы мы имели возможность изменить члены класса
        in >> segment.Point1.X;
        in >> segment.Point1.Y;

        in >> segment.Point2.X;
        in >> segment.Point2.Y;

        return in;
    }

    Segment(){
    Point1 = Point(0,0);
    Point2 = Point(1,0);
    }
    Segment(Point _Point1,Point _Point2){
    Point1 = _Point1;
    Point2 = _Point2;
    }
    Segment(double x1, double y1, double x2, double y2){
    Point1 = Point(x1,y1);
    Point2 = Point(x2,y2);
    }
    double getLength(){
        return sqrt( (Point1.X-Point2.X)*(Point1.X-Point2.X)+(Point1.Y-Point2.Y)*(Point1.Y-Point2.Y) );
    }

    Angle getRotation(){
        Segment S2;
        S2 = *this;
        S2.VectorStandartize();
        return S2.Point2.getRotation();
    }

    bool DoesContainPoint(Point P1){
        if ( (Point1 == P1) || (Point2 == P1) ){return 1;}

        Segment S2(Point1,P1), S3(Point2,P1);

        return S2.getRotation().isReverse(S3.getRotation());

    }

    double VectorDX(){return Point2.X - Point1.X; }
    double VectorDY(){return Point2.Y - Point1.Y; }

    friend Segment operator+(Segment &s1, Segment &s2){ /// Сложение Векторов в отрезок с коордами (0,0) (X,Y)
        return Segment(Point(0,0), Point( (s1.VectorDX())+(s2.VectorDX()),(s1.VectorDY())+(s2.VectorDY())));
    }

    double getScalValue(Segment s2){
    return VectorDX() * s2.VectorDX() + VectorDY() * s2.VectorDY();
    }

    double getVectValue(Segment s2){
    ///return (VectorDX() + VectorDY()) *   (s2.VectorDX() + s2.VectorDY());
    return VectorDX() * s2.VectorDY() - VectorDY()*s2.VectorDX();
    }

    void VectorStandartize(){ /// Превращение отрезка в отрезок с коордами вектора (0,0) (X,Y)
        Segment S1 = Segment(Point1,Point2);
        Segment S2 = Segment(0,0,0,0);

        Segment _test_ = S1 + S2;
        Point1 = Point(0,0);
        Point2 = _test_.Point2;
    }

    double distance_to_point(Point point_){

            Line nap_line(Point1,Point2);

            double a = Segment(point_,Point1).getLength();
            double c = Segment(point_,Point2).getLength();
            double b = getLength();

            double v1 = (a*a+b*b-c*c)/(2*a*b);
            double v2 = (c*c + b*b - a*a)/(2*b*c);
            if ((v1 > 0) && (v2 > 0)){
                return nap_line.distance_to_point(point_);
            }else{
                return min(a,c);
            }

    }

};


class Triangle{
public:
    Point Point1,Point2,Point3;
    Triangle(){
    Point1 = Point(0,0);
    Point2 = Point(1,0);
    Point3 = Point(0,1);
    }
    Triangle(Point _Point1,Point _Point2, Point _Point3){
    Point1= _Point1;
    Point2= _Point2;
    Point3= _Point3;
    }
    Triangle(double x1, double y1, double x2, double y2, double x3, double y3){
    Point1 = Point(x1,y1);
    Point2 = Point(x2,y2);
    Point3 = Point(x3,y3);
    }
    double getPerimeter(){
    return Segment(Point1,Point2).getLength() + Segment(Point2,Point3).getLength() + Segment(Point3,Point1).getLength();
    }
    double getArea(){
        double p= getPerimeter()/2;
    return sqrt(p*(p-Segment(Point1,Point2).getLength())*(p-Segment(Point2,Point3).getLength())*(p-Segment(Point3,Point1).getLength() ));
    }



};


#include <iomanip>

using namespace std;

int main()
{
     
    Point a,b;
    //cin >> a >> b;
    Line li;
    cin >> li;
    cin >> a;
    li.make_perpendicular_to_point(a);

    cout << fixed << setprecision(8)<<li;




    return 0;
}

