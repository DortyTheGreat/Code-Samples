#include <iostream>
#include "DortyLibs/DortyBuild.h"
#include "DortyLibs/DortyMath.h"
#include "DortyLibs/DortyString.h"
#include "DortyLibs/DortyGeometry.h"
#include <iomanip>

using namespace std;

int main()
{
    AppBuild();
    Point a,b;
    //cin >> a >> b;
    Line li;
    cin >> li;
    cin >> a;
    li.make_perpendicular_to_point(a);

    cout << fixed << setprecision(8)<<li;




    return 0;
}
