#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <queue>


#include "DortyGraph.h"
#include "DortyBuild.h"
using namespace std;




int main() {
    int H,W;
    cin >> H >> W;
    int Matrix[300][300];

    int ans = 0;

    for(int i =0;i<H;i++){
        for(int j =0;j<W;j++){
            char tmp;
            cin >> tmp;
            if (tmp == '.'){
                Matrix[i][j] = 1;
            }else{
                Matrix[i][j]=0;
            }
        }
    }

    for(int i =0;i<H;0){
            int flag =0;
        for(int j =0;j<W;j++){
            ans+= Matrix[i][j];
            if (i != (H-1)){
                if (Matrix[i][j] && Matrix[i+1][j]){flag = 1;}
            }
        }

        if (flag){
            i++;
        }else{
        break;
        }
    }

    cout << ans;

    return 0;
    //for(int i =0;i<n;i++){
    //    cout << G1.Nodes[i].value;
    //}


}
