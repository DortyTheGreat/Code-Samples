#include <iostream>
#include "DortyLibs/DortyBuild.h"

#include "DortyLibs/DortyMath.h"

#include <iomanip>
#include <algorithm>
using namespace std;

bool Unique(int num)
{
    if ((((num / 100) % 10) % 2 == 0) && ((num % 10) % 2 == 0))
    {
        vector<long long> ab = all_divisers(num);
        if (find(ab.begin(), ab.end(), 6) == ab.end())
        {
            if (find(ab.begin(), ab.end(), 7) == ab.end())
            {
                if (find(ab.begin(), ab.end(), 8) == ab.end())
                {
                    return true;
                }
            }
        } /// true -> ���� ����
    }

    return false;
}

bool razliv(int num)
{
    return (all_divisers(num).size() == 5);

    /*

    162271
166827
171337
175927


4 aka 2
    */
}



int main()
{
    ///AppBuild();

    int cou = 0;
    int last = 0;
    vector<vector<long long>> ab;
    //cout << all_divisers(12);
    ab = All_Multes(10,1200);

    cout << FHCN(1200) << endl;

    cout << all_divisers(36) <<endl;

    for (int i = 0; i < ab.size(); i++)
    {
        cout << ab[i] << endl;
    }

    return 0;
}
