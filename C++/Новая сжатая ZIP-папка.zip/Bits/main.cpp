#include "DortyLibs/BITS.h"
#include <algorithm>
#include "DortyLibs/DortyBigInt.h"
int main()
{
    /// �������
    AppBuild();

    ///print(reverse(input()));


    BigInt a,b;

    cin >> a;

    cout << a << endl;

    //fout.setf(ios_base::fixed);
    //fout.precision(8);

    //Polygon a;
    //fin >> a;
    //fout << Cake_algo(a);


}
