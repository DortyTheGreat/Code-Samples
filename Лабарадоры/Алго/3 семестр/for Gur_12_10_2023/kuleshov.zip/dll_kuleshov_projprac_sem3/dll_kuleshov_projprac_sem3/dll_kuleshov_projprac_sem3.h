﻿#pragma once

using namespace System;
using namespace System::Windows::Forms;

namespace dllkuleshovprojpracsem3 {
	public ref class Functions
	{
		public:
			// TODO: Добавьте сюда свои методы для этого класса.
			static int GetCheckBoxScore(CheckBox^ CB1, CheckBox^ CB2, CheckBox^ CB3, bool S1, bool S2, bool S3);
	};
}
